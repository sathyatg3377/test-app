import React from "react";
import TextField from '@material-ui/core/TextField';

const WorkStatusFields = props => {
  return props.workStatus.map((val, idx) => {
    let fromTime = `fromTime-${idx}`,
      toTime = `toTime-${idx}`,
      task = `task-${idx}`,
      taskDescription = `taskDescription-${idx}`;

    return (
      <div className="row customworkstatus-form" key={val.index}>
     
        <div >
          <label class="customlabel1-textcolor">{idx + 1}</label>
                 </div>
        <div className="col">
          <div  >
            <div className="col">
              <label class="customlabel-textcolor ">From Time</label>
            </div>
            <input
              defaultValue="00:00"
              type="time"
              name="fromTime"
              id={fromTime}
              data-id={idx}
              InputLabelProps={{
                shrink: true,
              }}
              className="form-control "
              required
            />
            <div className="col">
              <label class="customlabel-textcolor">To Time</label>
            </div>
            <input
             defaultValue="00:00"
              type="time"
              InputLabelProps={{
                shrink: true,
              }}
              className="form-control "
              name="toTime"
              id={toTime}
              data-id={idx}
              required
            />

          </div>
        </div>&nbsp;&nbsp;
        {/* <div className="col">
          <label class="customlabel-textcolor">To Time</label>
          <div className="col">
            <div>
              <input
                defaultValue="04:20"
                type="time"
                InputLabelProps={{
                  shrink: true,
                }}
                className="form-control required"
                name="toTime"
                id={toTime}
                data-id={idx}
              />
            </div>
          </div>
        </div> */}
        <div className="col">
          <label class="customlabel-textcolor">Title</label>
          <textarea class="form-control "
              placeholder="Task"
            name="task"
            rows="4"
            id={task}
            data-id={idx}
            required
          />
        </div>
        &nbsp;&nbsp;
        <div className="col">
          <label class="customlabel-textcolor">Task Description</label>
          <textarea class="form-control "
            placeholder="Task Description"
            name="taskDescription"
            rows="4"
            id={taskDescription}
            data-id={idx}
            required
          />
        </div>
        <div className="col p-4">
          {idx === 0 ? (
            <button
              onClick={() => props.add()}
              type="button"
              className="btn btn-primary text-center"
            >
              <i className="fa fa-plus-circle" aria-hidden="true" />
            </button>
          ) : (
            <button
              className="btn btn-danger"
              onClick={() => props.delete(val)}
            >
              <i className="fa fa-minus" aria-hidden="true" />
            </button>
          )}
        </div>
      </div>
    );
  });
};
export default WorkStatusFields;

